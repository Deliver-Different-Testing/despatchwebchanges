# Third-party notices

The lens approach is adapted from public work; no third-party source is vendored verbatim.

- **Refraction physics** (convex-squircle bezel, Snell's law) follows Kube's article
  "Liquid Glass in the Browser: Refraction with CSS and SVG" (https://kube.io/blog/liquid-glass-css-svg/).
