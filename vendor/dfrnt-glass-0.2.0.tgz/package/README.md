# @dfrnt/glass

Liquid-glass surfaces for DFRNT apps, shared by dfrntcrm and despatchweb.

| Browser | Strategy | How |
|---|---|---|
| Chrome / Edge | `svg` | Live page refraction: `backdrop-filter: url(#displacement)` with a generated displacement map (single pass; mounted 250 ms after open so the lens never animates) |
| Everything else, app-disabled, reduced-transparency, forced-colors | `css` | Plain frosted `.dfrnt-glass` |

There is deliberately no Safari/Firefox page-capture lens: it took seconds on busy pages.

Two tiers:

- **React + Mantine apps:** full package (lens + theme overrides + CSS).
- **Any other app (AngularJS, Bootstrap, plain HTML):** import only `glass.css` and add classes: `dfrnt-glass dfrnt-glass-panel` for a floating panel, `dfrnt-glass` alone for a scrim, `dfrnt-glass-on-scrim` for glass on the brand scrim. No refraction, same look otherwise.

## Install

`.npmrc` in the consuming repo (instance-level endpoint; GitLab requires the scope to match the root group):

```
@dfrnt:registry=https://git.customd.com/api/v4/packages/npm/
//git.customd.com/api/v4/packages/npm/:_authToken=${NPM_GITLAB_TOKEN}
```

`NPM_GITLAB_TOKEN` is a personal access token with `read_api` locally, and `CI_JOB_TOKEN` in CI.

```
npm install @dfrnt/glass
```

Peer dependencies: `react`, `react-dom`, `@mantine/core`, `@mantine/hooks`.

## Use

```ts
import { createTheme, mergeThemeOverrides } from '@mantine/core';
import { glassThemeOverrides } from '@dfrnt/glass';
import '@dfrnt/glass/glass.css';

export const theme = mergeThemeOverrides(createTheme({ /* app theme */ }), glassThemeOverrides);
```

That turns on: glass panels for Menu/Popover, glass scrim for Modal/Drawer, and the lens via `PopoverDropdown`. Tooltip and Notifications stay opaque on purpose.

Other exports: `glassClassNames` (for custom surfaces, e.g. `glassClassNames.onScrim`), `useGlassStrategy`, `useGlassAllowed`, `GlassDropdownRoot`, `SvgBackdropLens`, `renderDisplacementMap`, `GlassProvider`.

`GlassProvider enabled={…}` is the app-level switch (kill switch, user preference); default on. Off strips the glass material from dropdowns. Wrap the app (inside `MantineProvider`) with it. `dfrnt-glass-dialog` (combine with `dfrnt-glass-panel`) is the cheaper-blur variant for dialogs.

## Theming contract

The CSS reads one variable: `--dd-surface-container-high` (falls back to `Canvas`). Set it per app/tenant and the glass follows. Dark mode is keyed off `[data-mantine-color-scheme='dark']`.

## Develop

```
npm run dev        # demo page: stripes backdrop, Menu, Popover, scheme toggle. Open in Chrome, Safari, Firefox
npm test
npm run build
```

Tune visuals in `src/glass.css` (`.dfrnt-glass-panel`, `.dfrnt-glass-backdrop`, `.dfrnt-glass-layer::after`) and optics in `src/lens/lensConfig.ts`.

## Release

Tag `vX.Y.Z` on the default branch. CI publishes to this project's npm registry. Apps pin a range and upgrade deliberately.

## Known limits

- Snapshot strategy: inner scroll positions, cross-origin images without CORS, canvas and iframes may not render in the captured page; the CSS glass underneath covers failures.
- Modal/Drawer use the plain glass scrim only; the lens is applied to Menu/Popover dropdowns.
